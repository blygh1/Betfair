package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.enums.FileTypeEnum;

import java.util.List;

public interface ExportService {

    void exportFile(List<BetDataDto> betData, String fileName, FileTypeEnum fileType) ;
}
