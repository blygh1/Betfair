package com.betfair.betting.data.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class  ReportOneFormatDto {

    @JsonProperty("Selection Name")
    private String selectionName;
    @JsonProperty("Currency")
    private String currency;
    @JsonProperty("Num Bets")
    private Long betNumber;
    @JsonProperty("Total Stakes")
    private String totalStake;
    @JsonProperty("Total Liability")
    private String totalLiability;
    @JsonIgnore
    private Long selectionId;
    @JsonIgnore
    private Double totalStakeCount;
    @JsonIgnore
    private Double totalLiabilityCount;

    public ReportOneFormatDto() {
    }

    public ReportOneFormatDto(String selectionName, String currency, Long betNumber, String totalStake,
                              String totalLiability, Long selectionId, Double totalStakeCount, Double totalLiabilityCount) {
        this.selectionName = selectionName;
        this.currency = currency;
        this.betNumber = betNumber;
        this.totalStake = totalStake;
        this.totalLiability = totalLiability;
        this.selectionId = selectionId;
        this.totalStakeCount = totalStakeCount;
        this.totalLiabilityCount = totalLiabilityCount;
    }

    public String getSelectionName() {
        return selectionName;
    }

    public void setSelectionName(String selectionName) {
        this.selectionName = selectionName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Long getBetNumber() {
        return betNumber;
    }

    public void setBetNumber(Long betNumber) {
        this.betNumber = betNumber;
    }

    public String getTotalStake() {
        return totalStake;
    }

    public void setTotalStake(String totalStake) {
        this.totalStake = totalStake;
    }

    public String getTotalLiability() {
        return totalLiability;
    }

    public void setTotalLiability(String totalLiability) {
        this.totalLiability = totalLiability;
    }

    public Long getSelectionId() {
        return selectionId;
    }

    public void setSelectionId(Long selectionId) {
        this.selectionId = selectionId;
    }

    public Double getTotalStakeCount() {
        return totalStakeCount;
    }

    public void setTotalStakeCount(Double totalStakeCount) {
        this.totalStakeCount = totalStakeCount;
    }

    public Double getTotalLiabilityCount() {
        return totalLiabilityCount;
    }

    public void setTotalLiabilityCount(Double totalLiabilityCount) {
        this.totalLiabilityCount = totalLiabilityCount;
    }


}
