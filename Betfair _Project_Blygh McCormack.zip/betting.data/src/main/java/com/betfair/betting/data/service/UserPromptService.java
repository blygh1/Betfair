package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;

import java.util.List;
import java.util.Map;

public interface UserPromptService {

    void betfairUserIntro();

    List<BetDataDto> extractValidDataRowsFromFile(Map<String, String> fileInputType, List<BetDataDto> betDataDtoList);

    void sendForExport(List<BetDataDto> betDataDtoList, String outputFileType);
}
