package com.betfair.betting.data.enums;


public enum ErrorTypeEnum {

    EMPTY_OR_NULL_FIELD("Empty or null field.");
    private String error;


    ErrorTypeEnum(String errorType) {
        this.error = errorType;
    }

    public String errorType() {
        return error;
    }
}