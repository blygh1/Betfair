package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.enums.FileTypeEnum;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.google.common.io.Files;
import com.opencsv.CSVReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.*;

@Service
public class FileServiceImpl implements FileService {

    private final File resourcesDirectory = new File("src/main/resources/");
    private final String BACKSLASH = "\\";

    @Autowired
    BetDataMapper betDataMapper;

    private static final Logger log = LoggerFactory.getLogger(FileServiceImpl.class);

    public Map<String, String> getFileInputType(String inputString) {
        Map<String, String> inputDetails = new HashMap<>();
        String lowerCaseInputString = inputString.trim().toLowerCase();
        //http input
        if ((lowerCaseInputString.startsWith("http://") || lowerCaseInputString.startsWith("https://")) && isValidUrl(lowerCaseInputString)) {
            inputDetails.put(inputString, FileTypeEnum.HTTP.getType());
        } else {
            String fullPathFileName = resourcesDirectory.getAbsolutePath().concat(BACKSLASH).concat(inputString);
            File inputFile = new File(inputString);
            //check if full path supplied
            if (inputFile.exists()) {
                inputDetails.put(inputString,Files.getFileExtension(inputString));
            } else {
                inputFile = new File(fullPathFileName);
                //just a file name supplied
                //check if string supplied with file extension
                if (inputFile.exists()) {
                    inputDetails.put(fullPathFileName, Files.getFileExtension(fullPathFileName));
                } else {
                    //no file extension supplied, check all matching filename in resources folder
                    File[] filesFound = resourcesDirectory.listFiles();
                    for (int i = 0; i < resourcesDirectory.listFiles().length; i++) {
                        String fileName = filesFound[i].getName().replaceFirst("[.][^.]+$", "").toLowerCase();
                        if(fileName.equals(lowerCaseInputString)) {
                            //add file extension in
                            inputDetails.put(filesFound[i].getAbsolutePath(), Files.getFileExtension(filesFound[i].getName()));
                            break;
                        }

                    }
                }

            }
        }
        return inputDetails;
    }

    //send absolute path
    public List<BetDataDto> getCSVAndOrderBettingData(String inputFileName) {
        List<BetDataDto> betDataList = new ArrayList<>();
        List<String> expectedHeaderValue = BetDataDto.getSpecificColumnHeadingOrder();
        List<String> orderedList = Collections.emptyList();
        boolean listInCorrectOrder = false;
        try {

            CSVReader csvFile = new CSVReader(new FileReader(inputFileName));
            String[] values;
            int index = 0;
            boolean isValidCsvFile = true;
            boolean isCorrectOrderedHeader = false;

            while ((values = csvFile.readNext()) != null && isValidCsvFile) {
                //ignore the headers in reading the csv file
                if (index != 0 && isValidCsvFile) {
                    if(isCorrectOrderedHeader){
                        betDataList.add(betDataMapper.mapBetDataFromCsv(values));
                    }else{
                        List<String> incomingValues = Arrays.asList(values);
                        //add the correct order to list
                        sortIncomingListsAsExpectedOrder(incomingValues, expectedHeaderValue);

                        betDataList.add(betDataMapper.mapBetDataFromCsv(incomingValues.toArray(new String[incomingValues.size()])));
                    }

                } else {//if empty, not a valid csv file
                    List<String> incomingValues = Arrays.asList(values);

                    //check if column ordered correctly
                    isCorrectOrderedHeader = isCorrectOrderedList(incomingValues, expectedHeaderValue);

                    orderedList = checkForCorrectHeadersOnIncomingCsvFileAndOrder(incomingValues,expectedHeaderValue,isCorrectOrderedHeader);
                    isValidCsvFile = !orderedList.isEmpty();
                }
                index++;

            }
        } catch (IOException e) {
            log.error("Error in reading CSV file");
            log.error(e.getMessage());
            //print error message
        }
        return betDataList;
    }


    private List<String> checkForCorrectHeadersOnIncomingCsvFileAndOrder(List<String> incomingValues,List<String> expectedHeaderValue, boolean listsInCorrectOrder) {
        //check if the right headers are here to ensure we can map correctly
        List<String> orderedList = Collections.emptyList();
        //expected column size
        if (expectedHeaderValue.size() == incomingValues.size()) {
            //not expected order
            if (!listsInCorrectOrder) {
                //order as expected order
                sortIncomingListsAsExpectedOrder(incomingValues, expectedHeaderValue);
                orderedList = incomingValues;
            }else{
                //sort as expected order
                orderedList = incomingValues;

            }
        }else{
            System.out.println("Incoming data has incorrect headers amount");
        }
        return orderedList;
    }

    private boolean isValidUrl(String inputString) {
        try {
            new URL(inputString).toURI();
            return true;
        } catch (Exception e) {
            log.info(inputString.concat(" is not a valid URL"));
            return false;
        }
    }

    private boolean isCorrectOrderedList(List<String> incomingValues, List<String> expectedHeaderValue) {
        return incomingValues.equals(expectedHeaderValue)
                && expectedHeaderValue.equals(incomingValues);
    }

    private void sortIncomingListsAsExpectedOrder(List<String> incomingValues, List<String> expectedHeaderValue) {
        incomingValues.sort(Comparator.comparingInt(expectedHeaderValue::indexOf));
    }

}
