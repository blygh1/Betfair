package com.betfair.betting.data.enums;


public enum SupportedCurrencyTypeEnum {
    EUR("€"),
    GBP("£");

    private String symbol;

    SupportedCurrencyTypeEnum(String symbolType) {
        this.symbol = symbolType;
    }

    public String getSymbol() {
        return symbol;
    }


}