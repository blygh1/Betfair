package com.betfair.betting.data.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportTwoFormatDto {

    //order by  Currency and Total Liability
    @JsonProperty("Currency")
    private String currency;
    @JsonProperty("No of Bets")
    private String betNumber;
    @JsonProperty("Total Stakes")
    private String totalStake; //hash this info
    @JsonProperty("Total Liability")
    private String totalLiability;//hash this info
    @JsonIgnore
    private Long betNumberCount;
    @JsonIgnore
    private Double totalStakeCount; //hash this info
    @JsonIgnore
    private Double totalLiabilityCount;

    public ReportTwoFormatDto() {
    }

    public ReportTwoFormatDto(String currency, String betNumber, String totalStake, String totalLiability, Long betNumberCount) {
        this.currency = currency;
        this.betNumber = betNumber;
        this.totalStake = totalStake;
        this.totalLiability = totalLiability;
        this.betNumberCount = betNumberCount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getBetNumber() {
        return betNumber;
    }

    public void setBetNumber(String betNumber) {
        this.betNumber = betNumber;
    }

    public String getTotalStake() {
        return totalStake;
    }

    public void setTotalStake(String totalStake) {
        this.totalStake = totalStake;
    }

    public String getTotalLiability() {
        return totalLiability;
    }

    public void setTotalLiability(String totalLiability) {
        this.totalLiability = totalLiability;
    }

    public Long getBetNumberCount() {
        return betNumberCount;
    }

    public void setBetNumberCount(Long betNumberCount) {
        this.betNumberCount = betNumberCount;
    }

    public Double getTotalStakeCount() {
        return totalStakeCount;
    }

    public void setTotalStakeCount(Double totalStakeCount) {
        this.totalStakeCount = totalStakeCount;
    }

    public Double getTotalLiabilityCount() {
        return totalLiabilityCount;
    }

    public void setTotalLiabilityCount(Double totalLiabilityCount) {
        this.totalLiabilityCount = totalLiabilityCount;
    }
}
