package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.enums.FileTypeEnum;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

import static com.fasterxml.jackson.dataformat.csv.CsvSchema.builder;

@Service
public class ExportServiceImpl implements ExportService {

    private static final Logger log = LoggerFactory.getLogger(ExportServiceImpl.class);

    @Autowired
    private BetDataMapper betDataMapper;

    public void exportFile(List<BetDataDto> betData, String fileName, FileTypeEnum fileType) {
        ReportOutputDto reportOutputDto = betDataMapper.mapBetDataToReportFormat(betData);

        ObjectMapper mapper = new ObjectMapper();
        JsonNode reportOneJsonNode = mapper.valueToTree(reportOutputDto.getReportOne());
        JsonNode reportTwoJsonNode = mapper.valueToTree(reportOutputDto.getReportTwo());

        generateReport(fileName.concat("1"), reportOneJsonNode, fileType);
        generateReport(fileName.concat("2"), reportTwoJsonNode, fileType);

    }

    private void generateReport(String fileName, JsonNode jsonNode, FileTypeEnum fileType) {
        CsvSchema.Builder csvSchemaBuilder = builder();
        JsonNode firstObject = jsonNode.elements().next();
        firstObject.fieldNames().forEachRemaining(fieldName -> {csvSchemaBuilder.addColumn(fieldName);} );
        CsvSchema csvSchema = csvSchemaBuilder.build().withHeader();
        CsvMapper csvOutputMapper = new CsvMapper();
        try{
            //generate Report one
            csvOutputMapper.writerFor(JsonNode.class).with(csvSchema).writeValue(new File("src/main/resources/exports/"
                    .concat(fileName.concat(".").concat(fileType.getType()))), jsonNode);
            System.out.println(fileName.concat(" file exported successfully to resources."));
        }catch (Exception e){
            System.out.println("Error exporting file to ". concat(fileType.getType()));
        }
    }


}
