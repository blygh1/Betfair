package com.betfair.betting.data.mapper;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ReportOneFormatDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.dto.ReportTwoFormatDto;
import com.betfair.betting.data.enums.SupportedCurrencyTypeEnum;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class BetDataMapper {

    public BetDataDto mapBetDataFromCsv(String[] values) {
        BetDataDto incomingBetDataDto = new BetDataDto();

        //List will be correctly ordered at this stage
        for (int i = 0; i < values.length; i++) {

            switch (i) {
                case 0:
                    incomingBetDataDto.setBetId(values[i]);
                    break;
                case  1:
                 incomingBetDataDto.setBetTimestamp(values[i]);
                    break;
                case 2:
                    incomingBetDataDto.setSelectionId(Long.valueOf(values[i]));
                    break;
                case 3:
                    incomingBetDataDto.setSelectionName(values[i]);
                    break;
                case 4:
                    incomingBetDataDto.setStake(Double.valueOf((values[i])));
                    break;
                case 5:
                    incomingBetDataDto.setPrice(Double.valueOf((values[i])));
                    break;
                case 6:
                    incomingBetDataDto.setCurrency(values[i]);
                    break;

            }
        }

        return incomingBetDataDto;

    }

    public ReportOutputDto mapBetDataToReportFormat(List<BetDataDto> betDataList)  {
        ReportOutputDto reportOutputDto = new ReportOutputDto();
        List<ReportOneFormatDto> reportOneList = new ArrayList<>();
        List<ReportTwoFormatDto> reportTwoList = new ArrayList<>();

        for(BetDataDto dto: betDataList){
            Optional<ReportOneFormatDto> reportOneLine = getBySelectionAndCurrency(reportOneList, dto.getSelectionId(), dto.getCurrency());
            if(reportOneLine.isPresent()){
                reportOneLine.get().setBetNumber( reportOneLine.get().getBetNumber()+1);
                reportOneLine.get().setTotalStakeCount(reportOneLine.get().getTotalStakeCount()  + dto.getStake());
                reportOneLine.get().setTotalLiabilityCount(reportOneLine.get().getTotalLiabilityCount() + dto.getTotalLiability());

            }else{
                ReportOneFormatDto newReportOneLine = new ReportOneFormatDto();
                newReportOneLine.setSelectionName(dto.getSelectionName());
                newReportOneLine.setBetNumber(1l);
                newReportOneLine.setSelectionId(dto.getSelectionId());
                newReportOneLine.setCurrency(dto.getCurrency().toUpperCase());
                newReportOneLine.setTotalStakeCount(dto.getStake());
                newReportOneLine.setTotalLiabilityCount(dto.getTotalLiability());
                reportOneList.add(newReportOneLine);
            }

            Optional<ReportTwoFormatDto> reportTwoLine = getByCurrency(reportTwoList, dto.getCurrency());
            if(reportTwoLine.isPresent()){
                reportTwoLine.get().setTotalLiabilityCount( reportTwoLine.get().getTotalLiabilityCount() + dto.getTotalLiability());
                reportTwoLine.get().setTotalStakeCount(reportTwoLine.get().getTotalStakeCount() + dto.getStake());
                reportTwoLine.get().setBetNumberCount( reportTwoLine.get().getBetNumberCount() + 1);
            }else {
                ReportTwoFormatDto newReportTwoLine = new ReportTwoFormatDto();
                newReportTwoLine.setCurrency(dto.getCurrency());
                newReportTwoLine.setBetNumberCount(1l);
                newReportTwoLine.setTotalStakeCount(dto.getStake());
                newReportTwoLine.setTotalLiabilityCount(dto.getTotalLiability());
                reportTwoList.add(newReportTwoLine);
            }
        }
        reportOutputDto.setReportOne(addCurrencyCodeAndSort(reportOneList));
        reportOutputDto.setReportTwo(hidePriceInfo(reportTwoList));
        return reportOutputDto;

    }

    private List<ReportTwoFormatDto> hidePriceInfo(List<ReportTwoFormatDto> reportTwoList){
        List <ReportTwoFormatDto> formattedList = new ArrayList<>();
        DecimalFormat df = new DecimalFormat("#.00");
        for(ReportTwoFormatDto reportTwo: reportTwoList){
            ReportTwoFormatDto newReport =  reportTwo;
            String symbolPrefix = SupportedCurrencyTypeEnum.valueOf(reportTwo.getCurrency()).getSymbol();
            newReport.setBetNumber(String.valueOf(reportTwo.getBetNumberCount()).replaceAll("[0-9]", "xx"));
            newReport.setTotalStake(symbolPrefix.concat(df.format(reportTwo.getTotalStakeCount())).replaceAll("[0-9]", "*"));
            newReport.setTotalLiability(symbolPrefix.concat(df.format(reportTwo.getTotalLiabilityCount())).replaceAll("[0-9]", "*"));
            formattedList.add(newReport);
        }
        return formattedList;
    }


    private List <ReportOneFormatDto> addCurrencyCodeAndSort (List <ReportOneFormatDto> reportOneList){
        DecimalFormat df = new DecimalFormat("#.00");

        List <ReportOneFormatDto> formattedList = new ArrayList<>();
        for(ReportOneFormatDto reportOne: reportOneList){
            ReportOneFormatDto newReport = reportOne;
            String symbolPrefix = SupportedCurrencyTypeEnum.valueOf(reportOne.getCurrency()).getSymbol();
            newReport.setTotalLiability(symbolPrefix.concat(df.format(reportOne.getTotalLiabilityCount())));
            newReport.setTotalStake(symbolPrefix.concat(df.format(reportOne.getTotalStakeCount())));
            formattedList.add(newReport);
        }
        //sort List
        return formattedList.stream().sorted(Comparator.comparing(ReportOneFormatDto::getCurrency)
                .thenComparing(ReportOneFormatDto::getTotalLiabilityCount).reversed()).collect(Collectors.toList());

    }

    //select by selectionId and currency
    public Optional <ReportOneFormatDto> getBySelectionAndCurrency(final List<ReportOneFormatDto> list, final Long selectionId, final String currency){
        return list.stream().filter(o -> o.getSelectionId().equals(selectionId) && o.getCurrency().equals(currency)).findFirst();
    }

    public Optional <ReportTwoFormatDto> getByCurrency(final List<ReportTwoFormatDto> list, final String currency){
        return list.stream().filter(o -> o.getCurrency().equals(currency)).findFirst();
    }

}
