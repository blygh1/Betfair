package com.betfair.betting.data.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BetDataDto {

    //TODO -> check betId is unique
    private String betId;
    private String betTimestamp;
    private Long selectionId;
    private String selectionName;
    private Double stake;
    private Double price;
    private String currency;
    private Double totalLiability;

    private static List<String> columnHeading = new ArrayList<>();

    public BetDataDto() {
    }

    public BetDataDto(String betId, Long selectionId, String selectionName, Double stake, Double price, String currency,Double totalLiability) {
        this.betId = betId;
        this.selectionId = selectionId;
        this.selectionName = selectionName;
        this.stake = stake;
        this.price = price;
        this.currency = currency;
        this.totalLiability = totalLiability;
    }

    public static List<String> getSpecificColumnHeadingOrder() {
        columnHeading.add("betId");
        columnHeading.add("betTimestamp");
        columnHeading.add("selectionId");
        columnHeading.add("selectionName");
        columnHeading.add("stake");
        columnHeading.add("price");
        columnHeading.add("currency");

        return columnHeading;
    }

    public String getBetId() {
        return betId;
    }

    public void setBetId(String betId) {
        this.betId = betId;
    }

    public Double getStake() {
        return stake;
    }

    public void setStake(Double stake) {
        this.stake = stake;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getBetTimestamp() {
        return betTimestamp;
    }

    public void setBetTimestamp(String betTimestamp) {
        this.betTimestamp = betTimestamp;
    }

    public Long getSelectionId() {
        return selectionId;
    }

    public void setSelectionId(Long selectionId) {
        this.selectionId = selectionId;
    }

    public String getSelectionName() {
        return selectionName;
    }

    public void setSelectionName(String selectionName) {
        this.selectionName = selectionName;
    }


    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getTotalLiability() {
        return totalLiability;
    }

    public void setTotalLiability(Double totalLiability) {
        this.totalLiability = totalLiability;
    }
}
