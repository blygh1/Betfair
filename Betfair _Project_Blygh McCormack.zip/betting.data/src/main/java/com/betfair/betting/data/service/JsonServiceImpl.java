package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ErrorDto;
import com.betfair.betting.data.validate.FileValidator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class JsonServiceImpl implements JsonService  {

    private static final Logger log = LoggerFactory.getLogger(JsonServiceImpl.class);

    @Autowired
    private FileValidator validator;

    public List<BetDataDto> readJsonFromInput(String inputFileName){
        //Read Json from file
        List<BetDataDto> betDataList = Collections.emptyList();
        try{
            JsonNode jsonTree = new ObjectMapper().readTree(new File(inputFileName));
            betDataList = getValidBetDataList(jsonTree);
        }catch (IOException e){
            log.error(e.getMessage());
        }

        return betDataList;
    }

    private List<BetDataDto> getValidBetDataList(JsonNode jsonTree) {
        List<BetDataDto> betDataList;
        ObjectMapper mapper = new ObjectMapper();
        List<BetDataDto> jsonNodeAsMap = mapper.convertValue(jsonTree, new TypeReference<>(){});
        List <ErrorDto> errors = new ArrayList<>();
        betDataList = validator.validateBetData(jsonNodeAsMap, errors);
        return betDataList;
    }

    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    public List<BetDataDto> readJsonFromUrl(String url) throws MalformedURLException {
        List<BetDataDto> betDataList = Collections.emptyList();
        InputStream inputStream = null;
        try {
            inputStream = new URL(url).openStream();

            BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JsonNode jsonTree = new ObjectMapper().readTree(jsonText);
            betDataList = getValidBetDataList(jsonTree);
        } catch (IOException | JSONException e){
            System.out.println("Error getting Json for url: ".concat(url));
        }
            finally {
            try {
                if(inputStream!=null){
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return betDataList;
    }



}
