package com.betfair.betting.data.validate;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ErrorDto;
import com.betfair.betting.data.enums.ErrorTypeEnum;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class FileValidator {

    public  List<BetDataDto> validateBetData(List<BetDataDto> incomingJson, List <ErrorDto> errors){
        List<BetDataDto> validBetData = new ArrayList<>();
        Long index = 1l;

        //remove empty or null rows, could be further refined to include more cases
        for(BetDataDto dto : incomingJson ){
            boolean isValid = true;

            if(dto.getBetId() == null || dto.getBetId().isEmpty()){
                isValid = false;
                errors.add(new ErrorDto("BetId", ErrorTypeEnum.EMPTY_OR_NULL_FIELD, index));
            }else if(dto.getPrice() == null ){
                isValid = false;
                errors.add(new ErrorDto("Price", ErrorTypeEnum.EMPTY_OR_NULL_FIELD, index));
            }else if(dto.getStake() == null ){
                isValid = false;
                errors.add(new ErrorDto("Stake", ErrorTypeEnum.EMPTY_OR_NULL_FIELD, index));
            }else if(dto.getCurrency() == null || dto.getCurrency().isEmpty()){
                isValid = false;
                errors.add(new ErrorDto("Currency", ErrorTypeEnum.EMPTY_OR_NULL_FIELD, index));
            }else if(dto.getSelectionName() == null || dto.getSelectionName().isEmpty()){
                isValid = false;
                errors.add(new ErrorDto("Selection Name", ErrorTypeEnum.EMPTY_OR_NULL_FIELD, index));
            }
            if((dto.getStake() != null && dto.getPrice() != null)){
                dto.setTotalLiability(dto.getStake() * dto.getPrice());
            }
            if (isValid){
                validBetData.add(dto);
            }
            index++;
        }

        return validBetData;

    }


}
