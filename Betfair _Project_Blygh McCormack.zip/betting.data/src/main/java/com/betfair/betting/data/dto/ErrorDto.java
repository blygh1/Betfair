package com.betfair.betting.data.dto;

import com.betfair.betting.data.enums.ErrorTypeEnum;

public class ErrorDto {

    String fieldName;

    ErrorTypeEnum description;

    Long rowNum;

    public ErrorDto(String fieldName, ErrorTypeEnum description) {
        this.fieldName = fieldName;
        this.description = description;
    }

    public ErrorDto(String fieldName, ErrorTypeEnum description, Long rowNum) {
        this.fieldName = fieldName;
        this.description = description;
        this.rowNum = rowNum;
    }

    @Override
    public String toString() {
        return "Error with Data Line (" +
                "Field Name='" + fieldName + '\'' +
                ", Description=" + description +
                ", row Number=" + rowNum +
                ')';
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public ErrorTypeEnum getDescription() {
        return description;
    }

    public void setDescription(ErrorTypeEnum description) {
        this.description = description;
    }

    public void setRowNum(Long rowNum) {
        this.rowNum = rowNum;
    }

    public Long getRowNum() {
        return rowNum;
    }
}

