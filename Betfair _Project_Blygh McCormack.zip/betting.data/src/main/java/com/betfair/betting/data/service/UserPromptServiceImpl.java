package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ErrorDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.enums.FileTypeEnum;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.betfair.betting.data.validate.FileValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class UserPromptServiceImpl implements  UserPromptService {

    private static final Logger log = LoggerFactory.getLogger(UserPromptServiceImpl.class);

    @Autowired
    private FileService fileService;

    @Autowired
    private JsonService jsonService;

    @Autowired
    private ExportService exportService;

    @Autowired
    private FileValidator fileValidator;

    @Autowired
    private BetDataMapper betDataMapper;


    public void betfairUserIntro() {
        System.out.println("--------------------------------------------------");
        System.out.println("----Welcome to Betfair Data Export Application----");
        System.out.println("--------------------------------------------------");

        try{
            System.out.println("Please provide a file name from resources folder, full path of file or HTTP url: ");
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String inputFileName = reader.readLine();
            Map<String, String> fileInputType = fileService.getFileInputType(inputFileName);;
            List<BetDataDto> betDataDtoList = Collections.EMPTY_LIST;

            while(betDataDtoList.isEmpty()) {
                betDataDtoList = extractValidDataRowsFromFile(fileInputType, betDataDtoList);
                if(betDataDtoList.isEmpty() ){
                    System.out.println("--------------------------------------------------");
                    System.out.println((inputFileName).concat(" is not found or invalid."));
                    System.out.println("Please try again: ");
                    inputFileName = reader.readLine();
                    fileInputType = fileService.getFileInputType(inputFileName);
                }

            }
            System.out.println("--------------------------------------------------");
            System.out.println("Please provide a export format and file name(if csv):");
            System.out.println("1 -> for console || 2 -> for CSV file or 3 -> for txt file in resources folder... eg: 2 testExport");
            String outputFileType = reader.readLine();

            while(!((outputFileType.startsWith("1",0)
                    ||(outputFileType.startsWith("2" ,0)
                    || outputFileType.startsWith("3",0) && outputFileType.length() < 1)
                    || outputFileType.length() > 1))){
                System.out.println("Please try again: ");
                outputFileType = reader.readLine();
            }
            sendForExport(betDataDtoList, outputFileType);

        }catch (IOException e){
            log.error(e.getMessage());
        }


    }

    public void sendForExport(List<BetDataDto> betDataDtoList, String outputFileType) {
        try {
             if(outputFileType.startsWith("1",0)){
                ReportOutputDto reportOutputDto = betDataMapper.mapBetDataToReportFormat(betDataDtoList);
                reportOutputDto.printToConsole();

            }if(outputFileType.startsWith("2",0)){
                exportService.exportFile( betDataDtoList, outputFileType.substring(2, outputFileType.length()), FileTypeEnum.CSV);

            } else if(outputFileType.startsWith("3",0)){
                exportService.exportFile( betDataDtoList, outputFileType.substring(2, outputFileType.length()),FileTypeEnum.TEXT);
            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public List<BetDataDto>  extractValidDataRowsFromFile(Map<String, String> fileInputType, List<BetDataDto> betDataDtoList) {
        List<BetDataDto> validBetDataList = Collections.emptyList();
        for(Map.Entry<String, String> entry : fileInputType.entrySet()){
            String fileNameInput = entry.getKey();
            if(entry.getValue().equals(FileTypeEnum.CSV.getType())){
                betDataDtoList = fileService.getCSVAndOrderBettingData(fileNameInput);
            }
            else if(entry.getValue().toLowerCase().equals(FileTypeEnum.JSON.getType())){
                betDataDtoList = jsonService.readJsonFromInput(fileNameInput);
            }
            else if(entry.getValue().equals(FileTypeEnum.HTTP.getType())){
                try {
                    betDataDtoList = jsonService.readJsonFromUrl(fileNameInput);
                }catch (IOException e ){
                    System.out.println(e.getMessage());
                }
            } else{
                return validBetDataList;
            }

        }
        if(!betDataDtoList.isEmpty()){
            //validate row entries and remove any corrupt ones
            List<ErrorDto> errorsList = new ArrayList<>();
            validBetDataList = fileValidator.validateBetData(betDataDtoList, errorsList);
            if(!errorsList.isEmpty()){
                errorsList.stream().forEach(s ->System.out.println(s.toString()));
            }
            System.out.println("--------------------------------------------------");
            System.out.println( betDataDtoList.size() + " valid data row entries found in file supplied");
        }
        return validBetDataList;
    }

}
