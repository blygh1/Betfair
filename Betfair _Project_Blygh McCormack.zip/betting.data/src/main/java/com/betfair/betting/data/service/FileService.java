package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;

import java.util.List;
import java.util.Map;

public interface FileService {

    List<BetDataDto> getCSVAndOrderBettingData(String inputFileName);

    Map<String, String> getFileInputType(String inputString);
}
