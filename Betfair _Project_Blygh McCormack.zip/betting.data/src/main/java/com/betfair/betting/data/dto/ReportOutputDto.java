package com.betfair.betting.data.dto;

import java.util.ArrayList;
import java.util.List;

public class ReportOutputDto {
    List<ReportOneFormatDto> reportOne = new ArrayList<>();
    List<ReportTwoFormatDto> reportTwo = new ArrayList<>();


    public List<ReportOneFormatDto> getReportOne() {
        return reportOne;
    }

    public void setReportOne(List<ReportOneFormatDto> reportOne) {
        this.reportOne = reportOne;
    }

    public List<ReportTwoFormatDto> getReportTwo() {
        return reportTwo;
    }

    public void setReportTwo(List<ReportTwoFormatDto> reportTwo) {
        this.reportTwo = reportTwo;
    }

    @Override
    public String toString() {
        return "ReportOutputDto{" +
                "reportOne=" + reportOne +
                ", reportTwo=" + reportTwo +
                '}';
    }

    public void printToConsole(){
        System.out.println("------------------------------------------");
        System.out.println("Report One: Liability by Currency");
        System.out.println("------------------------------------------");
        System.out.println("-------------------------------------------------------------------------------------------------------");
        System.out.printf("%25s %5s %5s %15s %15s", "Selection Name", "Currency", "Num Bets", "Total Stakes", "Total Liability");
        System.out.println();
        System.out.println("-------------------------------------------------------------------------------------------------------");
        for(final ReportOneFormatDto one: reportOne){
            System.out.format("%25s %5s %5s %15s %15s\n",
                    one.getSelectionName(),one.getCurrency(),one.getBetNumber(),one.getTotalStake(), one.getTotalLiability());
        }
        System.out.println("-------------------------------------------------------------------------------------------------------");
        System.out.println();
        System.out.println("------------------------------------------");
        System.out.println("Report Two: Total Liability by Currency");
        System.out.println("------------------------------------------");
        System.out.println("-------------------------------------------------------------------------------------------------------");
        System.out.printf("%15s %15s %15s %18s", "Currency", "No Of Bets", "Total Stakes", "Total Liability");
        System.out.println();
        System.out.println("-------------------------------------------------------------------------------------------------------");
        for(final ReportTwoFormatDto two: reportTwo){
            System.out.format("%12s %12s %18s %18s\n", two.getCurrency(),two.getBetNumber(),two.getTotalStake(),two.getTotalLiability());
        }
        System.out.println("-------------------------------------------------------------------------------------------------------");

    }
}
