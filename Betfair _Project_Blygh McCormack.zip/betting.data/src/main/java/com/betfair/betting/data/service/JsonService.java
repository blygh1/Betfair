package com.betfair.betting.data.service;

import com.betfair.betting.data.dto.BetDataDto;

import java.net.MalformedURLException;
import java.util.List;

public interface JsonService {

    List<BetDataDto> readJsonFromInput(String inputFileName);

    List<BetDataDto> readJsonFromUrl(String url) throws MalformedURLException;
}
