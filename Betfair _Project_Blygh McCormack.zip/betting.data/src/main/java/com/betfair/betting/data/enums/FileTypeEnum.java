package com.betfair.betting.data.enums;


public enum FileTypeEnum{
    JSON("json"),
    CSV("csv"),
    TEXT("txt"),
    HTTP("http");

    private String type;


    FileTypeEnum(String typeData) {
        this.type = typeData;
    }

    public String getType() {
        return type;
    }
}