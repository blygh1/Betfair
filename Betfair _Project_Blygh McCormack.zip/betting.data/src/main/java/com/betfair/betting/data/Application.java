package com.betfair.betting.data;

import com.betfair.betting.data.service.UserPromptService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(Application.class);

	@Autowired
	private UserPromptService userPromptService;


	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}


	@Override
	public void run(String... args) {
		userPromptService.betfairUserIntro();
	}
}


/*
		TODO: Read from comma delimitied file and output to  console
		TODO: Change the following details
			1.Ask Source of the data
				a.Ask for CSV File or HTTP Request
					$i. Enter filename or direct PAth of file
					$ii.Enter URL for HTTP (JSON FORMAT)
						#1: Validate incoming data format,(CSV or JSON)
						#2: Validate fields and MAp to Object
						#3: Calculate Bet Liability = stake * price
			2.Ask Output of the data
				a. Output to text file
				b. Output to console
				c. Output to CSV file
					||#Reports generated:#||
			1. Selection liability by currency.
				a. Selection Name, Currency, Num Bets, Total Stakes, Total Liability
				b. Ordered By Currency and Total Liability, descending
			2. Total liability by Currency
				a. Currency, Num Bets, Total Stakes, Total Liability
		 */

