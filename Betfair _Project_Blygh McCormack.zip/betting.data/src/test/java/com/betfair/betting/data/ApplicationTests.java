package com.betfair.betting.data;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {

}
