package com.betfair.betting.data.serviceTest;

import com.betfair.betting.data.Application;
import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.enums.FileTypeEnum;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.betfair.betting.data.service.*;
import com.betfair.betting.data.utils.BetDataDtoFixture;
import com.betfair.betting.data.utils.FileTestUtils;
import com.betfair.betting.data.validate.FileValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@SpringBootTest(classes = {Application.class})
@RunWith(MockitoJUnitRunner.class)
public class UserPromptServiceImplTest {

    private FileTestUtils fileTestUtils;

    private ExportService exportService;

    private BetDataMapper betDataMapper;

    private UserPromptService userPromptService;

    private FileService fileService;

    private JsonService jsonService;

    BufferedReader reader;

    @Spy
    private FileValidator fileValidator;

    @Before
    public void init() {
        exportService = mock(ExportService.class);
        fileTestUtils = new FileTestUtils();
        fileValidator = new FileValidator();
        userPromptService = new UserPromptServiceImpl();
        jsonService = mock(JsonService.class);
        fileService = mock(FileService.class);
        betDataMapper = mock(BetDataMapper.class);
        reader = mock(BufferedReader.class);
        ReflectionTestUtils.setField(userPromptService, "fileService", fileService);
        ReflectionTestUtils.setField(userPromptService, "fileValidator", fileValidator);
        ReflectionTestUtils.setField(userPromptService, "jsonService", jsonService);
        ReflectionTestUtils.setField(userPromptService, "betDataMapper", betDataMapper);
        ReflectionTestUtils.setField(userPromptService, "exportService", exportService);


    }

    @Test
    public void extractValidDataRowsFromCsvFile() {
        List<BetDataDto> dataList = BetDataDtoFixture.getBetDataTestInfo();
        Map<String, String> fileInputType = new HashMap<>();
        String fileName = "betDataCsv.csv";
        assertTrue(fileTestUtils.checkFileIsCreated(fileName));
        String fullName = fileTestUtils.EXPORT_RESOURCES_PATH.concat(fileName);

        fileInputType.put(fullName, FileTypeEnum.CSV.getType());
        Mockito.when(fileService.getCSVAndOrderBettingData(fullName)).thenReturn(dataList);
        List<BetDataDto> extractValidDataRowsFromFile = userPromptService.extractValidDataRowsFromFile(fileInputType, dataList);
        assertTrue(extractValidDataRowsFromFile.size() == 8);
    }

    @Test
    public void extractValidDataRowsFromJsonFile() {
        List<BetDataDto> dataList = BetDataDtoFixture.getBetDataTestInfo();
        Map<String, String> fileInputType = new HashMap<>();
        String fileName = "testBetDataJSON.JSON";
        assertTrue(fileTestUtils.checkFileIsCreated(fileName));
        String fullName = fileTestUtils.EXPORT_RESOURCES_PATH.concat(fileName);

        fileInputType.put(fullName, FileTypeEnum.JSON.getType());
        Mockito.when(jsonService.readJsonFromInput(fullName)).thenReturn(dataList);
        List<BetDataDto> extractValidDataRowsFromFile = userPromptService.extractValidDataRowsFromFile(fileInputType, dataList);
        assertTrue(extractValidDataRowsFromFile.size() == 8);
    }

    @Test
    public void extractValidDataRowsFromHttpUrl() {
        List<BetDataDto> dataList = BetDataDtoFixture.getBetDataTestInfo();
        Map<String, String> fileInputType = new HashMap<>();
        String linkName = "http://test.com";

        fileInputType.put(linkName, FileTypeEnum.HTTP.getType());
        try{
            Mockito.when(jsonService.readJsonFromUrl(linkName)).thenReturn(dataList);
            List<BetDataDto> extractValidDataRowsFromFile = userPromptService.extractValidDataRowsFromFile(fileInputType, dataList);
            assertTrue(extractValidDataRowsFromFile.size() == 8);

        }catch (MalformedURLException e){
            System.out.println(e.getMessage());
        }

    }

    @Test
    public void extractValidDataRowsKo() {
        List<BetDataDto> dataList = BetDataDtoFixture.getBetDataTestInfo();
        Map<String, String> fileInputType = new HashMap<>();
        String fileName = "application.properties";

        fileInputType.put(fileName, "Invalid-Format");
        List<BetDataDto> extractValidDataRowsFromFile = userPromptService.extractValidDataRowsFromFile(fileInputType, dataList);
        assertTrue(extractValidDataRowsFromFile.isEmpty());
    }

    @Test
    public void testSendForExport(){
        List<BetDataDto> dataList = BetDataDtoFixture.getBetDataTestInfo();

        String outputTypeConsole = "1 consoleFile";
        userPromptService.sendForExport(dataList, outputTypeConsole);
        verify(betDataMapper, times(1)).mapBetDataToReportFormat(Mockito.anyList());

        String outputTypeCsv = "2 csvFile";
        userPromptService.sendForExport(dataList, outputTypeCsv);
        verify(exportService, times(1)).exportFile(Mockito.anyList(), Mockito.anyString(), Mockito.any());

        String outputTypeTxt = "3 txtFile";
        userPromptService.sendForExport(dataList, outputTypeTxt);
        verify(exportService, times(2)).exportFile(Mockito.anyList(), Mockito.anyString(), Mockito.any());

    }

    /*
    @Test
    public void testUserInput(){

        try {
            Mockito.when(reader.readLine())
                    .thenReturn("betDataCsv.csv");
            userPromptService.betfairUserIntro();
        }catch (IOException e){
            System.out.println(e.getMessage());
        }

    }
    */





}