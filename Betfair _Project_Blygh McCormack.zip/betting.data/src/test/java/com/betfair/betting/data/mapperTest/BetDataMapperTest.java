package com.betfair.betting.data.mapperTest;

import com.betfair.betting.data.Application;
import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ReportOneFormatDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.dto.ReportTwoFormatDto;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.betfair.betting.data.utils.BetDataDtoFixture;
import com.betfair.betting.data.utils.ReportOutputDtoFixture;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


@SpringBootTest(classes = {Application.class})
@ExtendWith(SpringExtension.class)
public class BetDataMapperTest {

    private BetDataMapper betDataMapper;

    public BetDataMapperTest(){
        betDataMapper = new BetDataMapper();
    }


    @Test
    public void testMappingBetDataAndSort(){
        List <BetDataDto> betDataList = BetDataDtoFixture.getBetDataTestInfo();
        ReportOutputDto expectedOutput  =ReportOutputDtoFixture.getReportOutputDtoTestData();
        ReportOutputDto receivedOutput = betDataMapper.mapBetDataToReportFormat(betDataList);
        List<ReportOneFormatDto> receivedReportOne = receivedOutput.getReportOne();
        List<ReportTwoFormatDto> receivedReportTwo = receivedOutput.getReportTwo();

        assertTrue(expectedOutput.getReportOne().size() == 6);
        assertTrue(expectedOutput.getReportTwo().size() == 2);

        //assert correct order and values
        for(int i = 0 ; i < receivedOutput.getReportOne().size(); i++){
            assertEquals(expectedOutput.getReportOne().get(i).getCurrency(), receivedReportOne.get(i).getCurrency());
            assertEquals(expectedOutput.getReportOne().get(i).getBetNumber(), receivedReportOne.get(i).getBetNumber());
            assertEquals(expectedOutput.getReportOne().get(i).getTotalLiability(), receivedReportOne.get(i).getTotalLiability());
            assertEquals(expectedOutput.getReportOne().get(i).getTotalStake(), receivedReportOne.get(i).getTotalStake());
            assertEquals(expectedOutput.getReportOne().get(i).getSelectionId(), receivedReportOne.get(i).getSelectionId());
            assertEquals(expectedOutput.getReportOne().get(i).getSelectionName(), receivedReportOne.get(i).getSelectionName());
        }

        for(int i = 0 ; i < receivedOutput.getReportTwo().size(); i++){
            assertEquals(expectedOutput.getReportTwo().get(i).getCurrency(), receivedReportTwo.get(i).getCurrency());
            assertEquals(expectedOutput.getReportTwo().get(i).getBetNumber(), receivedReportTwo.get(i).getBetNumber());
            assertEquals(expectedOutput.getReportTwo().get(i).getTotalLiability(), receivedReportTwo.get(i).getTotalLiability());
            assertEquals(expectedOutput.getReportTwo().get(i).getTotalStake(), receivedReportTwo.get(i).getTotalStake());
        }

    }

}
