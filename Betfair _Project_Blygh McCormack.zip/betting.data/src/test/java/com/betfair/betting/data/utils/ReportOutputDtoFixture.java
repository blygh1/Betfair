package com.betfair.betting.data.utils;

import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ReportOneFormatDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.dto.ReportTwoFormatDto;

import java.util.ArrayList;
import java.util.List;

public class ReportOutputDtoFixture {

    public static ReportOutputDto getReportOutputDtoTestData() {
        ReportOutputDto reportOutputDto = new ReportOutputDto();
        List<ReportOneFormatDto> reportOne = getReportOneData();
        List<ReportTwoFormatDto> reportTwo = getReportTwoData();
        reportOutputDto.setReportOne(reportOne);
        reportOutputDto.setReportTwo(reportTwo);
        return reportOutputDto;
    }


    public static List<ReportOneFormatDto> getReportOneData() {
        List<ReportOneFormatDto> reportOneList = new ArrayList<>();
        ReportOneFormatDto reportOne6 = new ReportOneFormatDto("Test1", "EUR",
                2l, "€11.40", "€35.00", 1l, 11.399999999999999, 35.0);
        ReportOneFormatDto reportOne5 = new ReportOneFormatDto("Test3", "EUR",
                2l, "€33.00", "€156.00", 3l, 33.0, 156.0);
        ReportOneFormatDto reportOne2 = new ReportOneFormatDto("Test1", "GBP",
                1l, "£5.00", "£350.00", 1l, 5.0, 350.0);
        ReportOneFormatDto reportOne1 = new ReportOneFormatDto("Test3", "GBP",
                1l, "£15.00", "£1200.00", 3l, 15.0, 1200.0);
        ReportOneFormatDto reportOne3 = new ReportOneFormatDto("Test4", "GBP",
                1l, "£10.00", "£200.00", 4l, 10.0, 20.0);
        ReportOneFormatDto reportOne4 = new ReportOneFormatDto("Test5", "EUR",
                1l, "€10.00", "€200.00", 5l, 10.0, 20.0);

        reportOneList.add(reportOne1);
        reportOneList.add(reportOne2);
        reportOneList.add(reportOne3);
        reportOneList.add(reportOne4);
        reportOneList.add(reportOne5);
        reportOneList.add(reportOne6);

        return reportOneList;

    }

    public static List<ReportTwoFormatDto> getReportTwoData() {
        List<ReportTwoFormatDto> reportTwoList = new ArrayList<>();
        ReportTwoFormatDto line1 = new ReportTwoFormatDto("EUR", "xx", "€**.**",
                "€***.**", 5l);

        ReportTwoFormatDto line2 = new ReportTwoFormatDto("GBP", "xx", "£**.**",
                "£****.**", 3l);
        reportTwoList.add(line1);
        reportTwoList.add(line2);

        return reportTwoList;
    }

}
