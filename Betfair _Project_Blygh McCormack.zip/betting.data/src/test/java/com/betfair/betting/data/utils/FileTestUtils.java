package com.betfair.betting.data.utils;

import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileTestUtils {

    public final static String EXPORT_RESOURCES_PATH = "src/main/resources/exports/";

    public boolean checkFileIsCreated(String fileName){
        File file = new File(EXPORT_RESOURCES_PATH.concat(fileName));
        return (file.exists());
    }

    public boolean ensureFileIsDeleted(String fileName){
        try{
            Files.deleteIfExists(Paths.get(EXPORT_RESOURCES_PATH.concat(fileName)));
        } catch (IOException e) {
            System.out.println("Error deleting file".concat(e.getMessage()));
        }
        File file = new File(EXPORT_RESOURCES_PATH.concat(fileName));
        return (!file.exists());
    }

    public boolean createTempFile(String fileName) throws IOException{
        File file = new File(EXPORT_RESOURCES_PATH.concat(fileName));
        return (file.createNewFile());
    }
}
