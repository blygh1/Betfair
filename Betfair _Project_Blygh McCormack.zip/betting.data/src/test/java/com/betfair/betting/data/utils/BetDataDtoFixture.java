package com.betfair.betting.data.utils;

import com.betfair.betting.data.dto.BetDataDto;

import java.util.ArrayList;
import java.util.List;

public class BetDataDtoFixture {

    public static List<BetDataDto> getBetDataTestInfo(){
        String euroCurrency  = "EUR";
        String poundCurrency = "GBP";
        List<BetDataDto> betDataList = new ArrayList<>();

        betDataList.add(new BetDataDto("Bet-1", 1l, "Test1", 5.85, 3.0, euroCurrency, 15.0));
        betDataList.add(new BetDataDto("Bet-2", 1l, "Test2", 5.55, 4.0, euroCurrency, 20.0));
        betDataList.add(new BetDataDto("Bet-3", 3l, "Test3", 8.0, 7.0, euroCurrency,56.0));
        betDataList.add(new BetDataDto("Bet-4", 1l, "Test1", 5.0, 70.0, poundCurrency,350.0 ));
        betDataList.add(new BetDataDto("Bet-5", 3l, "Test3", 25.0, 4.0, euroCurrency,100.0));
        betDataList.add(new BetDataDto("Bet-6", 3l, "Test3", 15.0, 80.0, poundCurrency, 1200.0));
        betDataList.add(new BetDataDto("Bet-7", 4l, "Test4", 10.0, 20.0, poundCurrency, 200.0));
        betDataList.add(new BetDataDto("Bet-8", 5l, "Test5", 10.0, 20.0, euroCurrency, 200.0));

        return betDataList;
    }

}
