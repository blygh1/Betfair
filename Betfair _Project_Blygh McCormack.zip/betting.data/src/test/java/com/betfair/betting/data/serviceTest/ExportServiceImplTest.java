package com.betfair.betting.data.serviceTest;

import com.betfair.betting.data.Application;
import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.dto.ReportOutputDto;
import com.betfair.betting.data.enums.FileTypeEnum;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.betfair.betting.data.service.ExportService;
import com.betfair.betting.data.service.ExportServiceImpl;
import com.betfair.betting.data.utils.BetDataDtoFixture;
import com.betfair.betting.data.utils.FileTestUtils;
import com.betfair.betting.data.utils.ReportOutputDtoFixture;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.imageio.IIOException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

@SpringBootTest(classes = {Application.class})
@RunWith(MockitoJUnitRunner.class)
public class ExportServiceImplTest {

    private FileTestUtils fileTestUtils;

    private ExportService exportService;

    private BetDataMapper betDataMapper;

    @Before
    public void init(){
        exportService = new ExportServiceImpl() ;
        fileTestUtils = new FileTestUtils();
        betDataMapper = mock(BetDataMapper.class);
        ReflectionTestUtils.setField(exportService, "betDataMapper", betDataMapper);
    }


    @Test
    public void testExportCsvFile() {
        ReportOutputDto expectedOutput  = ReportOutputDtoFixture.getReportOutputDtoTestData();
        List <BetDataDto> inputData = BetDataDtoFixture.getBetDataTestInfo();
        String fileName = "betDataCsvTest";
        String fileName1 = "betDataCsvTest1.csv";
        String fileName2 = "betDataCsvTest2.csv";

        assertTrue(fileTestUtils.ensureFileIsDeleted(fileName1));
        assertTrue(fileTestUtils.ensureFileIsDeleted(fileName2));

        Mockito.when(betDataMapper.mapBetDataToReportFormat(Mockito.anyList())).thenReturn(expectedOutput);
        exportService.exportFile(inputData,fileName, FileTypeEnum.CSV);

        assertTrue(fileTestUtils.checkFileIsCreated(fileName1));
        assertTrue(fileTestUtils.checkFileIsCreated(fileName2));

    }


    @Test
    public void testExportTextFile() {
        ReportOutputDto expectedOutput  = ReportOutputDtoFixture.getReportOutputDtoTestData();
        List <BetDataDto> inputData = BetDataDtoFixture.getBetDataTestInfo();
        String fileName = "betDataTextTest";
        String fileName1 = "betDataTextTest1.txt";
        String fileName2 = "betDataTextTest2.txt";

        assertTrue(fileTestUtils.ensureFileIsDeleted(fileName1));
        assertTrue(fileTestUtils.ensureFileIsDeleted(fileName2));

        Mockito.when(betDataMapper.mapBetDataToReportFormat(Mockito.anyList())).thenReturn(expectedOutput);
        exportService.exportFile(inputData,fileName, FileTypeEnum.TEXT);

        assertTrue(fileTestUtils.checkFileIsCreated(fileName1));
        assertTrue(fileTestUtils.checkFileIsCreated(fileName2));
    }



}