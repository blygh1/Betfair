package com.betfair.betting.data.serviceTest;

import com.betfair.betting.data.Application;
import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.enums.FileTypeEnum;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.betfair.betting.data.service.FileService;
import com.betfair.betting.data.service.FileServiceImpl;
import com.betfair.betting.data.utils.FileTestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;

@SpringBootTest(classes = {Application.class})
@ExtendWith(SpringExtension.class)
public class FileServiceImplTest {

    private FileService fileService;

    private FileTestUtils fileTestUtils;

    private BetDataMapper betDataMapper;

    @Before
    public void init(){
        betDataMapper = new BetDataMapper();
        fileTestUtils = new FileTestUtils();
        fileService = new FileServiceImpl();
        ReflectionTestUtils.setField(fileService, "betDataMapper", betDataMapper);

    }


    @Test
    public void testGetFileInputTypeHttp() {
        Map<String, String> output = fileService.getFileInputType("http://test.com");
        assertTrue(output.size() ==1 );
        assertTrue(output.entrySet().stream().map(entry -> entry.getValue().equals(FileTypeEnum.HTTP.getType())).findFirst().isPresent());
    }

    @Test
    public void testGetFileInputTypeFileName() throws IOException {
        String inputName = "betdataCsv";
        String fileName = "betdataCsv.csv";
        assertTrue(fileTestUtils.ensureFileIsDeleted(fileName));
        assertTrue(fileTestUtils.createTempFile(fileName));
        assertTrue(fileTestUtils.checkFileIsCreated(fileName));

        Map<String, String> output = fileService.getFileInputType(inputName);
        assertTrue(output.size() ==1 );
        assertTrue(output.entrySet().stream().map(entry -> entry.getValue().equals(FileTypeEnum.CSV.getType())).findFirst().isPresent());
    }

    @Test
    public void testGetFileInputTypeFileNameFullEx() throws IOException {
        String inputName = "betdataCsv";
        String fileName = "betdataCsv.csv";
        assertTrue(fileTestUtils.ensureFileIsDeleted(fileName));
        assertTrue(fileTestUtils.createTempFile(fileName));
        assertTrue(fileTestUtils.checkFileIsCreated(fileName));

        Map<String, String> output = fileService.getFileInputType(inputName);
        assertTrue(output.size() ==1 );
        assertTrue(output.entrySet().stream().map(entry -> entry.getValue().equals(FileTypeEnum.CSV.getType())).findFirst().isPresent());
    }


    @Test
    public void testInCorrectColumnHeadersOrder(){
        //do not want to delete this file for the test
        String fileInputName = "testCsvOrderWrongHeadingOrder.csv";
        assertTrue(fileTestUtils.checkFileIsCreated(fileInputName));
        List<BetDataDto> output = fileService.getCSVAndOrderBettingData(fileTestUtils.EXPORT_RESOURCES_PATH.concat(fileInputName));

        assertTrue(output.size() == 24);
    }
}