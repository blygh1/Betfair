package com.betfair.betting.data.serviceTest;

import com.betfair.betting.data.Application;
import com.betfair.betting.data.dto.BetDataDto;
import com.betfair.betting.data.mapper.BetDataMapper;
import com.betfair.betting.data.service.JsonService;
import com.betfair.betting.data.service.JsonServiceImpl;
import com.betfair.betting.data.utils.FileTestUtils;
import com.betfair.betting.data.validate.FileValidator;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.MalformedURLException;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@SpringBootTest(classes = {Application.class})
@ExtendWith(SpringExtension.class)
public class JsonServiceImplTest {

    private JsonService jsonService;

    private BetDataMapper betDataMapper;

    private FileTestUtils fileTestUtils;

    @Spy
    private FileValidator validator;


    @Before
    public void init() {
        jsonService = new JsonServiceImpl();
        betDataMapper = new BetDataMapper();
        fileTestUtils = new FileTestUtils();
        validator = new FileValidator();
        ReflectionTestUtils.setField(jsonService, "validator", validator);

    }

    @Test
    public void testGetJsonFromFileOk(){
        String fileName = "emptyJson.JSON";
        assertFalse(fileTestUtils.checkFileIsCreated(fileName));
        List<BetDataDto> jsonData = jsonService.readJsonFromInput(FileTestUtils.EXPORT_RESOURCES_PATH.concat(fileName));
        assertTrue(jsonData.size() == 0);

    }

    @Test
    public void testGetJsonFromFileKo(){
        String fileName = "testBetDataJSON.JSON";
        assertTrue(fileTestUtils.checkFileIsCreated(fileName));
        List<BetDataDto> jsonData = jsonService.readJsonFromInput(FileTestUtils.EXPORT_RESOURCES_PATH.concat(fileName));
        assertTrue(jsonData.size() == 24);

    }


    @Test
    public void readJsonFromUrlOk() {
        //online Json File
        try {
            List<BetDataDto> testData= jsonService.readJsonFromUrl("https://next.json-generator.com/api/json/get/E1BnUuFKu");;
            assertTrue(testData.size() == 24);

        }catch (MalformedURLException e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void readJsonFromUrlKo() {
        //online Json File
        try {
            List<BetDataDto> testData= jsonService.readJsonFromUrl("https://fail-json.com");;
            assertTrue(testData.isEmpty());

        }catch (MalformedURLException e){
            System.out.println(e.getMessage());
        }
    }
}