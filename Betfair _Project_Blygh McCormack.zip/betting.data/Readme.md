##BETFAIR DATA APPLICATION

>Features: <br /><br />
>Read JSON/CSV from entering filename, directory or Http URL <br />
>Input examples include : <br />
>* betDataCsv
>* betdatacsv.csv
>* fullPath Name + Full File Name
>* betDataJson.JSON
>
>Exported to resources/exports folder via txt,csv or to console:
<br /><br /><br />
>
>##Possible improvements: <br />
>* Added testing( ran short of time)
>* Bdd's with JBehave to show flows
>* Harden validation on incoming data(eg, check Id is unique)
>* Added support for every currency
>
>
><br />
>  Tested using Google Sheets as Microsoft license has expired for excel.